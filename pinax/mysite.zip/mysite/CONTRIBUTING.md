# How to Contribute

Please check out the Pinax Docs [How to Contribute](http://pinaxproject.com/pinax/how_to_contribute/) guide.
