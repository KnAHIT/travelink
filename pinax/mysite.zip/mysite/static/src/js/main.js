window.jQuery = window.$ = require("jquery");

require("bootstrap");

require("../less/site.less");
